# T-Gen decisions and assumptions

- Engine target: Godot 4.4.1, GDScript, Compatibility renderer, Android landscape.
- The supplied map image remains a design reference; the playable world is drawn from runtime geometry rather than using the map image as a background.
- Existing starter code is retained and extended rather than replaced with unrelated code.
- Initial player stats remain HP 100 / MP 50; MP regeneration is 1 point per second; level-up adds 12 max HP and 5 max MP.
- Basic attack, fire projectile, ice projectile, wind slash and Earth Spike are prototype implementations with simplified hit rules.
- Coin pickups are dropped by defeated enemies. Health potions have an 18% chance to drop and heal 20 HP when collected.
- Enemy spawner creates a regional enemy near the player every 8 seconds, avoids the village, and caps alive enemies at 12.
- Day/night loop lasts 4 real-time minutes (provisional); the world receives a blue night tint and the phase is displayed in the HUD.
- The current game is a first playable prototype, not a content-complete RPG. Production sprites, robust navigation, full inventory/equipment, deeper NPC interactions, balance testing and device testing remain future work.
