# T-Gen v0.2 — integration pass

## Implemented in the project files
- Main menu scene is now the application entry point; Start opens `MainWorld.tscn`.
- Earth Spike skill is available as a fourth skill button, with a mana cost and area-target damage.
- Defeated enemies drop physical ground pickups instead of awarding coins immediately.
- Coin pickups grant coins on proximity; health potions restore HP on proximity.
- Potion drops are random (18% chance) to avoid flooding the world with healing items.
- A capped proximity spawner adds regional enemies every 8 seconds (maximum 12 alive).
- Day/night phase advances in real time, tints the world at night, and is shown in the HUD.
- Blacksmith purchase now persistently adds +5 basic-attack damage per 20 coins.
- Save data version 2 includes weapon bonus, validates key values, accepts version 1 saves, and writes through a temporary file before replacement.
- GitHub Actions workflow retained for a cloud Android export.

## Not yet production-complete
- The world and characters are still procedural placeholder art drawn in GDScript.
- Enemy AI uses direct steering rather than full navigation/pathfinding.
- Pickups and enemy deaths are not persisted across app restarts.
- Inventory/equipment are not yet a full 20-slot data-driven inventory; the current prototype only has coins, potion pickup healing, elemental Understanding and a basic weapon bonus.
- The engine is not installed in this build environment, so Godot parser/runtime validation and an actual APK export could not be executed here.
