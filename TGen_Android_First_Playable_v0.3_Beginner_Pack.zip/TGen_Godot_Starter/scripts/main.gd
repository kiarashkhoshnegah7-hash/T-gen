extends Node2D

# T-Gen v0.1 playable prototype. Art is deliberately placeholder geometry.
const TILE := 32.0
const WORLD_TILES := 160
const WORLD_SIZE := TILE * WORLD_TILES
const SAVE_PATH := "user://tgen_save.json"

var player_pos := Vector2(800, 800)
var player_facing := Vector2.DOWN
var player_speed := 220.0
var hp := 100.0
var max_hp := 100.0
var mp := 50.0
var max_mp := 50.0
var level := 1
var xp := 0
var coins := 0
var understanding := {"fire": 0, "ice": 0, "wind": 0, "earth": 0}
var learned_skills: Array[String] = ["fire_bolt"]
var active_skills: Array[String] = ["fire_bolt", "ice_bolt", "wind_slash"]
var enemies: Array[Dictionary] = []
var projectiles: Array[Dictionary] = []
var pickups: Array[Dictionary] = []
var spawn_timer := 0.0
var day_time := 0.0
var day_length_seconds := 240.0
var weapon_bonus := 0.0
var blockers: Array[Rect2] = []
var ui: CanvasLayer
var hud_label: Label
var message_label: Label
var touch_vector := Vector2.ZERO
var joystick_touch := -1
var joystick_origin := Vector2.ZERO
var joystick_current := Vector2.ZERO
var attack_requested := false
var skill_requested := -1
var interact_requested := false
var elapsed := 0.0
var save_timer := 0.0
var world_rng := RandomNumberGenerator.new()
var trees: Array[Vector2] = []
var rocks: Array[Vector2] = []
var decor: Array[Dictionary] = []
var pois: Array[Dictionary] = []
var last_message := "به دنیای T-Gen خوش آمدی!"
var message_time := 4.0

func _ready() -> void:
	world_rng.seed = 824771
	_generate_world()
	_load_game()
	_spawn_initial_enemies()
	_build_ui()
	update_hud()
	queue_redraw()

func _process(delta: float) -> void:
	elapsed += delta
	message_time = maxf(0.0, message_time - delta)
	mp = minf(max_mp, mp + delta * 1.0)
	var move := _movement_input()
	if move.length() > 1.0:
		move = move.normalized()
	if move.length() > 0.08:
		player_facing = move.normalized()
	_move_player(move * player_speed * delta)
	_update_enemies(delta)
	_update_projectiles(delta)
	_update_pickups(delta)	
	_update_spawner(delta)
	day_time = fmod(day_time + delta, day_length_seconds)
	if attack_requested:
		_basic_attack()
		attack_requested = false
	if skill_requested >= 0:
		_cast_skill(skill_requested)
		skill_requested = -1
	if interact_requested:
		_interact()
		interact_requested = false
	save_timer += delta
	if save_timer >= 20.0:
		save_timer = 0.0
		_save_game()
	update_hud()
	queue_redraw()

func _movement_input() -> Vector2:
	var v := touch_vector
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): v.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): v.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): v.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): v.y += 1.0
	return v

func _generate_world() -> void:
	# Blockers and points are runtime placeholder geometry; the supplied map remains a reference only.
	pois = [
		{"name":"خانه", "rect":Rect2(Vector2(650, 520), Vector2(110, 85)), "color":Color("#ad7c54"), "kind":"home"},
		{"name":"کتابخانه", "rect":Rect2(Vector2(850, 520), Vector2(125, 90)), "color":Color("#6488bd"), "kind":"library"},
		{"name":"آهنگری", "rect":Rect2(Vector2(1050, 550), Vector2(120, 90)), "color":Color("#9d5c49"), "kind":"smith"},
		{"name":"انجمن", "rect":Rect2(Vector2(790, 360), Vector2(150, 100)), "color":Color("#d1b56e"), "kind":"guild"},
		{"name":"ورودی معدن", "rect":Rect2(Vector2(500, 3550), Vector2(100, 75)), "color":Color("#5a596c"), "kind":"mine"}
	]
	for poi in pois:
		var r: Rect2 = poi.rect
		blockers.append(Rect2(r.position + Vector2(5, 18), Vector2(r.size.x - 10, r.size.y - 18)))
	for i in range(430):
		var p := Vector2(world_rng.randf_range(90, WORLD_SIZE-90), world_rng.randf_range(90, WORLD_SIZE-90))
		if _region_at(p) == "forest" and _near_poi(p, 100) == false:
			trees.append(p)
			blockers.append(Rect2(p + Vector2(-10, 0), Vector2(20, 20)))
	for i in range(210):
		var p := Vector2(world_rng.randf_range(90, WORLD_SIZE-90), world_rng.randf_range(90, WORLD_SIZE-90))
		if _region_at(p) in ["grassland", "cliffs"] and not _near_poi(p, 90):
			rocks.append(p)
	for i in range(750):
		var p := Vector2(world_rng.randf_range(0, WORLD_SIZE), world_rng.randf_range(0, WORLD_SIZE))
		decor.append({"p":p, "type":world_rng.randi_range(0, 3)})

func _region_at(p: Vector2) -> String:
	if p.x < 1550 and p.y < 1550: return "village"
	if p.x > 2550 and p.y < 2450: return "forest"
	if p.x < 1500 and p.y > 2800: return "mine"
	if p.x > 2600 and p.y > 2600: return "cliffs"
	return "grassland"

func _near_poi(p: Vector2, radius: float) -> bool:
	for poi in pois:
		if poi.rect.get_center().distance_to(p) < radius: return true
	return false

func _spawn_initial_enemies() -> void:
	enemies.clear()
	_add_enemy("slime", Vector2(1050, 880), 35, 5, 1, 4, 5)
	_add_enemy("slime", Vector2(1180, 960), 35, 5, 1, 4, 5)
	_add_enemy("wolf", Vector2(3020, 750), 60, 9, 2, 12, 12)
	_add_enemy("goblin", Vector2(3360, 1050), 50, 8, 2, 12, 11)
	_add_enemy("treant", Vector2(3500, 1750), 140, 18, 5, 40, 40)
	_add_enemy("elemental", Vector2(3500, 3500), 90, 12, 3, 24, 25)

func _add_enemy(kind: String, pos: Vector2, enemy_hp: float, dmg: float, defense: float, coin_drop: int, xp_drop: int) -> void:
	enemies.append({"kind":kind,"pos":pos,"home":pos,"hp":enemy_hp,"max_hp":enemy_hp,"damage":dmg,"def":defense,"coins":coin_drop,"xp":xp_drop,"attack_cd":0.0,"hit_flash":0.0,"alive":true})

func _move_player(delta_pos: Vector2) -> void:
	var next := player_pos + Vector2(delta_pos.x, 0)
	if not _blocked_at(next): player_pos.x = clampf(next.x, 35, WORLD_SIZE-35)
	next = player_pos + Vector2(0, delta_pos.y)
	if not _blocked_at(next): player_pos.y = clampf(next.y, 35, WORLD_SIZE-35)

func _blocked_at(p: Vector2) -> bool:
	for b in blockers:
		if b.has_point(p + Vector2(0, 10)) or b.has_point(p + Vector2(-8, 8)) or b.has_point(p + Vector2(8, 8)): return true
	return false

func _basic_attack() -> void:
	var hit_any := false
	for e in enemies:
		if not e.alive: continue
		var diff: Vector2 = e.pos - player_pos
		if diff.length() <= 70 and diff.normalized().dot(player_facing) > 0.1:
			_damage_enemy(e, 18 + weapon_bonus, "slash")
			hit_any = true
	if not hit_any: _say("شمشیرت را در هوا چرخاندی.")

func _cast_skill(index: int) -> void:
	var skill := ["fire_bolt", "ice_bolt", "wind_slash", "earth_spike"][clampi(index, 0, 3)]
	if skill == "fire_bolt":
		if mp < 8: _say("مانای کافی نداری."); return
		mp -= 8
		projectiles.append({"pos":player_pos + player_facing*24,"vel":player_facing*430,"life":1.3,"damage":28,"kind":"fire"})
		_say("گلوله آتشین!")
	elif skill == "ice_bolt":
		if mp < 10: _say("مانای کافی نداری."); return
		mp -= 10
		projectiles.append({"pos":player_pos + player_facing*24,"vel":player_facing*360,"life":1.5,"damage":22,"kind":"ice"})
		_say("گلوله یخی!")
	elif skill == "wind_slash":
		if mp < 7: _say("مانای کافی نداری."); return
		mp -= 7
		for e in enemies:
			if e.alive and (e.pos-player_pos).length() <= 100 and (e.pos-player_pos).normalized().dot(player_facing) > -0.15:
				_damage_enemy(e, 20, "wind")
		_say("برش باد!")
	else:
		if mp < 12: _say("مانای کافی نداری."); return
		mp -= 12
		var target := player_pos + player_facing * 76.0
		var hit_count := 0
		for e in enemies:
			if e.alive and e.pos.distance_to(target) <= 48.0:
				_damage_enemy(e, 38, "earth")
				hit_count += 1
		_say("نیزهٔ زمین! %d هدف" % hit_count)

func _damage_enemy(e: Dictionary, amount: float, _type: String) -> void:
	if not e.alive: return
	e.hp -= maxf(1.0, amount - float(e.def)*0.25)
	e.hit_flash = 0.12
	if e.hp <= 0:
		e.alive = false
		_spawn_pickup("coin", int(e.coins), e.pos + Vector2(-8, 0))
		if world_rng.randf() < 0.18:
			_spawn_pickup("health_potion", 20, e.pos + Vector2(12, 4))
		xp += int(e.xp)
		_say("دشمن شکست خورد! آیتم روی زمین افتاد؛ +%d تجربه" % int(e.xp))
		_check_level_up()

func _update_enemies(delta: float) -> void:
	for e in enemies:
		if not e.alive: continue
		e.attack_cd = maxf(0.0, float(e.attack_cd)-delta)
		e.hit_flash = maxf(0.0, float(e.hit_flash)-delta)
		var pos: Vector2 = e.pos
		var dist := pos.distance_to(player_pos)
		var aggro := 230.0 if e.kind in ["slime", "elemental"] else 280.0
		if dist < aggro and dist > 43:
			var speed := 65.0
			if e.kind == "wolf": speed = 105.0
			elif e.kind == "treant": speed = 32.0
			elif e.kind == "elemental": speed = 75.0
			var dir := (player_pos-pos).normalized()
			var step := dir*speed*delta
			var target := pos+step
			if not _blocked_at(target): e.pos = target
		elif dist <= 48 and e.attack_cd <= 0:
			hp = maxf(0, hp-float(e.damage))
			e.attack_cd = 1.15 if e.kind != "treant" else 2.0
			_say("ضربه خوردی! -%d HP" % int(e.damage))
			if hp <= 0:
				hp = max_hp
				mp = max_mp
				player_pos = Vector2(800, 800)
				coins = maxi(0, coins-5)
				_say("از پا افتادی و به روستا برگشتی. ۵ سکه از دست دادی.")

func _update_projectiles(delta: float) -> void:
	for i in range(projectiles.size()-1, -1, -1):
		var p: Dictionary = projectiles[i]
		p.pos += p.vel*delta
		p.life -= delta
		var hit := false
		for e in enemies:
			if e.alive and e.pos.distance_to(p.pos) < 25:
				_damage_enemy(e, float(p.damage), str(p.kind))
				hit = true
				break
		if hit or p.life <= 0 or p.pos.x < 0 or p.pos.y < 0 or p.pos.x > WORLD_SIZE or p.pos.y > WORLD_SIZE:
			projectiles.remove_at(i)

func _spawn_pickup(item_type: String, amount: int, at: Vector2) -> void:
	pickups.append({"type": item_type, "amount": amount, "pos": at})

func _update_pickups(_delta: float) -> void:
	for i in range(pickups.size()-1, -1, -1):
		var item: Dictionary = pickups[i]
		if player_pos.distance_to(item.pos) <= 28.0:
			if item.type == "coin":
				coins += int(item.amount)
				_say("%d سکه برداشتی." % int(item.amount))
			else:
				var old_hp := hp
				hp = minf(max_hp, hp + float(item.amount))
				_say("معجون سلامتی: +%d HP" % int(hp-old_hp))
			pickups.remove_at(i)

func _update_spawner(delta: float) -> void:
	spawn_timer += delta
	if spawn_timer < 8.0: return
	spawn_timer = 0.0
	var alive_count := 0
	for e in enemies:
		if e.alive: alive_count += 1
	if alive_count >= 12: return
	var angle := world_rng.randf_range(0.0, TAU)
	var distance := world_rng.randf_range(300.0, 520.0)
	var candidate := player_pos + Vector2(cos(angle), sin(angle))*distance
	candidate.x = clampf(candidate.x, 80.0, WORLD_SIZE-80.0)
	candidate.y = clampf(candidate.y, 80.0, WORLD_SIZE-80.0)
	if _blocked_at(candidate): return
	var region := _region_at(candidate)
	if region == "village": return
	match region:
		"forest": _add_enemy("wolf", candidate, 60, 9, 2, 8, 12)
		"cliffs": _add_enemy("elemental", candidate, 90, 12, 3, 15, 25)
		"mine": _add_enemy("goblin", candidate, 50, 8, 2, 8, 11)
		_: _add_enemy("slime", candidate, 35, 5, 1, 4, 5)

func _day_phase_name() -> String:
	var phase := day_time/day_length_seconds
	if phase < 0.45: return "روز"
	if phase < 0.55: return "غروب"
	if phase < 0.90: return "شب"
	return "طلوع"

func _check_level_up() -> void:
	while xp >= level*40:
		xp -= level*40
		level += 1
		max_hp += 12
		max_mp += 5
		hp = max_hp
		mp = max_mp
		_say("لول آپ! سطح %d" % level)

func _interact() -> void:
	var nearest: Dictionary = {}
	var best := 999999.0
	for poi in pois:
		var d: float = poi.rect.get_center().distance_to(player_pos)
		if d < best:
			best = d
			nearest = poi
	if nearest.is_empty() or best > 135:
		_say("چیزی برای تعامل نزدیکت نیست.")
		return
	match str(nearest.kind):
		"home":
			hp = max_hp; mp = max_mp
			_say("استراحت کردی؛ HP و MP کامل شد.")
		"library":
			if coins >= 15:
				coins -= 15
				var element := "fire"
				for key in ["fire", "ice", "wind", "earth"]:
					if int(understanding[key]) < 100: element = key; break
				understanding[element] = mini(100, int(understanding[element])+25)
				_say("کتاب %s خریدی؛ درک عنصر: %d%%" % [element, int(understanding[element])])
			else: _say("کتاب ۱۵ سکه قیمت دارد.")
		"smith":
			if coins >= 20:
				coins -= 20
				weapon_bonus += 5
				_say("سلاح تقویت شد؛ آسیب حمله پایه +۵")
			else: _say("آهنگر: برای خرید تجهیزات ۲۰ سکه جمع کن.")
		"guild": _say("انجمن ماجراجویان؛ مأموریت‌ها در به‌روزرسانی آینده اضافه می‌شوند.")
		"mine": _say("ورودی معدن؛ سیاه‌چال داخلی برای نسخه بعدی برنامه‌ریزی شده.")
	_save_game()

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var panel := PanelContainer.new()
	panel.position = Vector2(12, 10)
	panel.custom_minimum_size = Vector2(300, 88)
	ui.add_child(panel)
	var vb := VBoxContainer.new()
	panel.add_child(vb)
	hud_label = Label.new()
	hud_label.add_theme_font_size_override("font_size", 17)
	vb.add_child(hud_label)
	message_label = Label.new()
	message_label.position = Vector2(320, 18)
	message_label.size = Vector2(500, 38)
	message_label.add_theme_font_size_override("font_size", 18)
	message_label.add_theme_color_override("font_color", Color("#fff0bf"))
	ui.add_child(message_label)
	var joystick := TouchPad.new()
	joystick.position = Vector2(20, 330)
	joystick.size = Vector2(170, 170)
	joystick.vector_changed.connect(func(v: Vector2): touch_vector = v)
	ui.add_child(joystick)
	var attack := _make_button("حمله", Vector2(815, 420), Vector2(125, 95))
	attack.pressed.connect(func(): attack_requested = true)
	var fire := _make_button("آتش", Vector2(720, 355), Vector2(80, 58))
	fire.pressed.connect(func(): skill_requested = 0)
	var ice := _make_button("یخ", Vector2(815, 335), Vector2(80, 58))
	ice.pressed.connect(func(): skill_requested = 1)
	var wind := _make_button("باد", Vector2(720, 425), Vector2(80, 58))
	wind.pressed.connect(func(): skill_requested = 2)
	var earth := _make_button("زمین", Vector2(620, 425), Vector2(80, 58))
	earth.pressed.connect(func(): skill_requested = 3)
	var interact := _make_button("تعامل", Vector2(420, 440), Vector2(105, 55))
	interact.pressed.connect(func(): interact_requested = true)
	var save_btn := _make_button("ذخیره", Vector2(840, 12), Vector2(100, 42))
	save_btn.pressed.connect(func(): _save_game(); _say("بازی ذخیره شد."))

func _make_button(caption: String, pos: Vector2, sz: Vector2) -> Button:
	var b := Button.new()
	b.text = caption
	b.position = pos
	b.size = sz
	b.add_theme_font_size_override("font_size", 18)
	ui.add_child(b)
	return b

func update_hud() -> void:
	if is_instance_valid(hud_label):
		hud_label.text = "سطح %d   HP %.0f/%.0f   MP %.0f/%.0f\nتجربه %d/%d   سکه %d   %s" % [level,hp,max_hp,mp,max_mp,xp,level*40,coins, _day_phase_name()]
	if is_instance_valid(message_label):
		message_label.text = last_message if message_time > 0 else ""

func _say(text: String) -> void:
	last_message = text
	message_time = 3.0

func _save_game() -> void:
	var data := {"version":2,"player_pos":[player_pos.x,player_pos.y],"hp":hp,"mp":mp,"max_hp":max_hp,"max_mp":max_mp,"level":level,"xp":xp,"coins":coins,"understanding":understanding,"learned_skills":learned_skills,"weapon_bonus":weapon_bonus}
	var temp_path := SAVE_PATH + ".tmp"
	var file := FileAccess.open(temp_path, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.flush()
		file.close()
		var source := ProjectSettings.globalize_path(temp_path)
		var destination := ProjectSettings.globalize_path(SAVE_PATH)
		if FileAccess.file_exists(SAVE_PATH):
			DirAccess.remove_absolute(destination)
		var rename_error := DirAccess.rename_absolute(source, destination)
		if rename_error != OK:
			push_warning("T-Gen save replacement failed: %s" % error_string(rename_error))

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		_save_game()

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH): return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file: return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY or int(parsed.get("version", 0)) < 1 or int(parsed.get("version", 0)) > 2: return
	var p = parsed.get("player_pos", [800,800])
	if p is Array and p.size() >= 2: player_pos = Vector2(float(p[0]),float(p[1]))
	hp = float(parsed.get("hp",100)); mp = float(parsed.get("mp",50))
	max_hp = float(parsed.get("max_hp",100)); max_mp = float(parsed.get("max_mp",50))
	level = int(parsed.get("level",1)); xp = int(parsed.get("xp",0)); coins = int(parsed.get("coins",0))
	understanding = parsed.get("understanding", understanding)
	weapon_bonus = float(parsed.get("weapon_bonus", 0.0))
	hp = clampf(hp, 0.0, max_hp)
	mp = clampf(mp, 0.0, max_mp)
	player_pos.x = clampf(player_pos.x, 35.0, WORLD_SIZE-35.0)
	player_pos.y = clampf(player_pos.y, 35.0, WORLD_SIZE-35.0)

func _draw() -> void:
	var cam := player_pos - Vector2(480, 270)
	# Ocean boundary.
	draw_rect(Rect2(-cam, Vector2(WORLD_SIZE,WORLD_SIZE)), Color("#254e75"), true)
	# World ground is painted in large region rectangles.
	draw_rect(Rect2(Vector2(0,0)-cam, Vector2(WORLD_SIZE,WORLD_SIZE)), Color("#527c45"), true)
	draw_rect(Rect2(Vector2(0,0)-cam, Vector2(1550,1550)), Color("#6d9b59"), true)
	draw_rect(Rect2(Vector2(1550,800)-cam, Vector2(1250,2200)), Color("#719b54"), true)
	draw_rect(Rect2(Vector2(2550,0)-cam, Vector2(2570,2450)), Color("#315d3e"), true)
	draw_rect(Rect2(Vector2(0,2800)-cam, Vector2(1500,2320)), Color("#686d70"), true)
	draw_rect(Rect2(Vector2(2600,2600)-cam, Vector2(2520,2520)), Color("#807c8e"), true)
	# Water boundary/shore and decorative grass specks.
	for d in decor:
		var p: Vector2 = d.p-cam
		if p.x < -20 or p.y < -20 or p.x > 980 or p.y > 560: continue
		var col := Color("#86b66a") if int(d.type)==0 else (Color("#b5c77d") if int(d.type)==1 else Color("#3f7445"))
		draw_rect(Rect2(p, Vector2(2,2)), col, true)
	for p0 in trees:
		var p: Vector2 = p0-cam
		if p.x < -40 or p.y < -40 or p.x > 1000 or p.y > 600: continue
		draw_circle(p+Vector2(0,2), 16, Color("#24422f"))
		draw_circle(p, 13, Color("#397448"))
		draw_circle(p+Vector2(-4,-5), 7, Color("#4f8b52"))
	for p0 in rocks:
		var p: Vector2 = p0-cam
		if p.x < -25 or p.y < -25 or p.x > 990 or p.y > 590: continue
		draw_colored_polygon(PackedVector2Array([p+Vector2(-10,5),p+Vector2(-5,-6),p+Vector2(6,-9),p+Vector2(12,4),p+Vector2(4,9)]), Color("#8c9695"))
	for poi in pois:
		var r: Rect2 = poi.rect
		var rr := Rect2(r.position-cam,r.size)
		if rr.end.x < -30 or rr.position.x > 990 or rr.end.y < -30 or rr.position.y > 590: continue
		draw_rect(rr, Color("#4d463f"), true)
		draw_rect(Rect2(rr.position+Vector2(4,4),rr.size-Vector2(8,8)), poi.color, true)
		draw_rect(Rect2(rr.position+Vector2(rr.size.x*0.42,rr.size.y-18),Vector2(20,18)), Color("#4a3429"), true)
		draw_string(ThemeDB.fallback_font, rr.position+Vector2(0,-7), str(poi.name), HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color.WHITE)
	# Player shadow/body/face; replace with real sprites in the art pass.
	var pp := player_pos-cam
	draw_circle(pp+Vector2(0,14), 10, Color(0,0,0,0.25))
	draw_rect(Rect2(pp+Vector2(-8,-12),Vector2(16,24)), Color("#202c43"), true)
	draw_rect(Rect2(pp+Vector2(-7,-16),Vector2(14,12)), Color("#d8b08b"), true)
	draw_rect(Rect2(pp+Vector2(-8,-18),Vector2(16,6)), Color("#24212d"), true)
	draw_line(pp, pp+player_facing*25, Color("#dbe7ee"), 4)
	# Enemies and HP bars.
	for e in enemies:
		if not e.alive: continue
		var ep: Vector2 = e.pos-cam
		if ep.x < -35 or ep.y < -35 or ep.x > 995 or ep.y > 595: continue
		var ec := Color("#75d45b")
		match str(e.kind):
			"wolf": ec = Color("#a7a7b3")
			"goblin": ec = Color("#4ab26a")
			"treant": ec = Color("#806347")
			"elemental": ec = Color("#8bdcf0")
		draw_circle(ep, 15 if e.kind != "treant" else 21, Color("#263a2c"))
		draw_circle(ep, 12 if e.kind != "treant" else 18, ec if float(e.hit_flash)<=0 else Color.WHITE)
		draw_rect(Rect2(ep+Vector2(-16,-24),Vector2(32,4)), Color("#352e32"), true)
		draw_rect(Rect2(ep+Vector2(-16,-24),Vector2(32*maxf(0,float(e.hp))/float(e.max_hp),4)), Color("#e45e5e"), true)
	for p in projectiles:
		var pp2: Vector2 = p.pos-cam
		var pc := Color("#ff8b38") if p.kind=="fire" else Color("#9deeff")
		draw_circle(pp2, 8, pc)
	# Ground pickups are physical world objects collected by proximity.
	for item in pickups:
		var ip: Vector2 = item.pos-cam
		if ip.x < -20 or ip.y < -20 or ip.x > 980 or ip.y > 560: continue
		if item.type == "coin":
			draw_circle(ip, 8, Color("#6b4817")); draw_circle(ip, 5, Color("#ffd34f"))
		else:
			draw_circle(ip, 8, Color("#702b38")); draw_rect(Rect2(ip+Vector2(-4,-5),Vector2(8,11)), Color("#f25d69"), true)
	# Dynamic day/night tint.
	var phase := day_time / day_length_seconds
	var night_strength := 0.0
	if phase >= 0.52 and phase < 0.92: night_strength = sin((phase-0.52)/0.40*PI)
	if night_strength > 0.0: draw_rect(Rect2(Vector2.ZERO, Vector2(960,540)), Color(0.05,0.07,0.22,night_strength*0.42), true)
	# Region labels, as live UI text rather than baked map text.
	var region := _region_at(player_pos)
	var region_name := {"village":"روستا", "grassland":"دشت", "forest":"جنگل", "mine":"معدن", "cliffs":"صخره‌های جادویی"}.get(region,"دشت")
	draw_string(ThemeDB.fallback_font, Vector2(410, 520), region_name, HORIZONTAL_ALIGNMENT_CENTER, 200, 17, Color("#fff4c9"))

class TouchPad extends Control:
	signal vector_changed(value: Vector2)
	var finger_id := -1
	var origin := Vector2.ZERO
	var current := Vector2.ZERO
	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		queue_redraw()
	func _gui_input(event: InputEvent) -> void:
		if event is InputEventScreenTouch:
			if event.pressed and finger_id == -1:
				finger_id = event.index; origin = event.position; current = event.position
			elif not event.pressed and event.index == finger_id:
				finger_id = -1; current = origin; vector_changed.emit(Vector2.ZERO)
			queue_redraw()
		elif event is InputEventScreenDrag and event.index == finger_id:
			current = event.position
			var v := (current-origin).limit_length(58)/58.0
			vector_changed.emit(v)
			queue_redraw()
		elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				finger_id = 0; origin = event.position; current = event.position
			else:
				finger_id = -1; vector_changed.emit(Vector2.ZERO)
			queue_redraw()
		elif event is InputEventMouseMotion and finger_id == 0 and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
			current = event.position
			vector_changed.emit((current-origin).limit_length(58)/58.0)
			queue_redraw()
	func _draw() -> void:
		var center := size*0.5
		draw_circle(center, 68, Color(0.03,0.05,0.07,0.35))
		draw_circle(center, 35, Color(0.6,0.75,0.8,0.12))
		var knob := center
		if finger_id != -1: knob += (current-origin).limit_length(48)
		draw_circle(knob, 24, Color(0.75,0.85,0.9,0.55))
