extends Control

func _ready() -> void:
	$Center/VBox/PlayButton.pressed.connect(_start_game)
	$Center/VBox/QuitButton.pressed.connect(_quit_game)

func _start_game() -> void:
	get_tree().change_scene_to_file("res://MainWorld.tscn")

func _quit_game() -> void:
	get_tree().quit()
